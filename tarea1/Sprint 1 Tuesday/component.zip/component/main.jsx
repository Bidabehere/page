import React from 'react';
export default function Main(props){
    return (
        <div>
            <img src={props.imagen} alt="" style={{eigth:'100px', width:'200px'}}/>
        </div>
    )
}
